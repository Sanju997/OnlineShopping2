package com.training.online_shopping.service;

public interface URLServices {

    final static String USER_URL="redirect:/customer/user.htm";
    final static String CART_SHOW_URL="redirect:/customer/cart/show?";
}
